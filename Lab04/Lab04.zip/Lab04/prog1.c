#include<stdio.h>  //add input output header file

/* 
	@copyright
	company
	author
	date
	inputs, funcitons, outputs
*/

int main(void){
	/*
	void main (void){}
	void main(){}
	int main(){}
	*/
	
	int students = 40;
	
	
	
	printf("You're a Bitch\n");
	printf("Live, Laugh, Roblox\n");
	printf("%d\n", students);
	printf("There are %d studentes in the class.\n", 40);
	printf("There will be %d studentes in each lab.\n", students/2);
	return 0;
}